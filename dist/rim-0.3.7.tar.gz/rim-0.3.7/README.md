# RIM
The code repository for the Python implementation of the Ray Intersection Model (RIM) - for analyzing betweenness of spatial objects.
